"""PheroOS command line package."""
