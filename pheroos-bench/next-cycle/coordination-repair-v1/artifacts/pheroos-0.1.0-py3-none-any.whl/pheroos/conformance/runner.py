from __future__ import annotations

from collections.abc import Callable
from hashlib import sha256
from pathlib import Path
from typing import Any

from pheroos.conformance.checks import (
    authority_ledger_contract,
    candidate_declaration,
    certificate_conflict_contract,
    certificate_output_contract,
    challenge_coverage_contract,
    collective_policy,
    commit_authority_boundary,
    commit_certificate_contract,
    commit_channel_separation,
    commit_liveness_contract,
    commit_metrics_contract,
    commit_numeric_contract,
    commit_policy_contract,
    commit_trace_contract,
    commit_window_contract,
    counterevidence_contract,
    domain_neutrality,
    distributed_finality_contract,
    driver_lifecycle_boundary,
    driver_contract,
    extension_contract,
    hybrid_authority_boundary,
    hybrid_trace_contract,
    kernel_contract,
    kernel_import_boundary,
    layer_coordination_policy,
    manifest_schema,
    membership_snapshot_contract,
    no_assurance_downgrade,
    observation_binding_contract,
    output_contract,
    policy_adjustment_bounds,
    principal_attestation_contract,
    public_abi_boundary,
    quorum_policy,
    recovery_policy,
    risk_monotonicity_contract,
    runtime_scope_contract,
    safe_fallback_collective,
    score_breakdown_contract,
    source_surface,
    support_lease_contract,
    trace_contract,
    trace_store_contract,
)
from pheroos.conformance.profile import (
    MANIFEST_PROFILE,
    SOURCE_PROFILE,
    ConformanceProfile,
    profile_for_manifest,
)
from pheroos.conformance._manifest_check_registry import (
    REGISTERED_MANIFEST_CHECK_NAMES,
)
from pheroos.conformance.report import (
    PHEROOS_IMPLEMENTATION_ID,
    CheckResult,
    ConformanceReport,
    ConformanceSubjectKind,
)
from pheroos.protocol.loader import load_capability_manifest
from pheroos.protocol.models import CapabilityManifest


ManifestCheck = Callable[[CapabilityManifest], CheckResult]


MANIFEST_CHECKS: dict[str, ManifestCheck] = {
    "candidate_declaration": candidate_declaration.check,
    "quorum_policy": quorum_policy.check,
    "collective_policy": collective_policy.check,
    "safe_fallback_collective": safe_fallback_collective.check,
    "score_breakdown_contract": score_breakdown_contract.check,
    "layer_coordination_policy": layer_coordination_policy.check,
    "policy_adjustment_bounds": policy_adjustment_bounds.check,
    "hybrid_trace_contract": hybrid_trace_contract.check,
    "hybrid_authority_boundary": hybrid_authority_boundary.check,
    "commit_policy_contract": commit_policy_contract.check,
    "commit_trace_contract": commit_trace_contract.check,
    "commit_numeric_contract": commit_numeric_contract.check,
    "principal_attestation_contract": principal_attestation_contract.check,
    "risk_monotonicity_contract": risk_monotonicity_contract.check,
    "membership_snapshot_contract": membership_snapshot_contract.check,
    "observation_binding_contract": observation_binding_contract.check,
    "counterevidence_contract": counterevidence_contract.check,
    "challenge_coverage_contract": challenge_coverage_contract.check,
    "support_lease_contract": support_lease_contract.check,
    "commit_metrics_contract": commit_metrics_contract.check,
    "commit_channel_separation": commit_channel_separation.check,
    "commit_window_contract": commit_window_contract.check,
    "commit_liveness_contract": commit_liveness_contract.check,
    "commit_authority_boundary": commit_authority_boundary.check,
    "commit_certificate_contract": commit_certificate_contract.check,
    "certificate_output_contract": certificate_output_contract.check,
    "distributed_finality_contract": distributed_finality_contract.check,
    "certificate_conflict_contract": certificate_conflict_contract.check,
    "no_assurance_downgrade": no_assurance_downgrade.check,
    "recovery_policy": recovery_policy.check,
    "output_contract": output_contract.check,
    "trace_contract": trace_contract.check,
    "driver_contract": driver_contract.check,
    "kernel_contract": kernel_contract.check,
    "extension_contract": extension_contract.check,
}

if tuple(MANIFEST_CHECKS) != REGISTERED_MANIFEST_CHECK_NAMES:
    raise RuntimeError(
        "manifest check callable registry does not match its static identities"
    )


def validate_manifest(path: str | Path) -> ConformanceReport:
    manifest_path = Path(path)
    checks = [safe_check("manifest_schema", manifest_schema.check, manifest_path)]
    checks.append(profile_contract_check(MANIFEST_PROFILE, checks))
    return ConformanceReport(
        target=str(manifest_path),
        checks=tuple(checks),
        profile=MANIFEST_PROFILE.version,
        subject_kind=ConformanceSubjectKind.MANIFEST,
        implementation_identity=PHEROOS_IMPLEMENTATION_ID,
        artifact_digest=artifact_digest(manifest_path),
    )


def run_conformance(path: str | Path) -> ConformanceReport:
    """Run only the checks declared by the manifest-selected ABI profile.

    Source-boundary proof is a separate versioned profile exposed by
    :func:`run_source_conformance`.
    """
    target = Path(path)
    manifest_path = target / "capability.json" if target.is_dir() else target
    checks = [safe_check("manifest_schema", manifest_schema.check, manifest_path)]
    profile = MANIFEST_PROFILE
    if checks[0].ok:
        try:
            manifest = load_capability_manifest(manifest_path)
            profile = profile_for_manifest(manifest)
        except Exception as exc:  # total-function boundary for CLI consumers
            checks.append(exception_result("manifest_load", exc))
        else:
            for check_name in profile.required_checks:
                if check_name == "manifest_schema":
                    continue
                check = MANIFEST_CHECKS.get(check_name)
                if check is None:
                    checks.append(
                        CheckResult(
                            check_name, False, "check implementation is not registered"
                        )
                    )
                    continue
                checks.append(safe_check(check_name, check, manifest))
    checks.append(profile_contract_check(profile, checks))
    return ConformanceReport(
        target=str(target),
        checks=tuple(checks),
        profile=profile.version,
        subject_kind=ConformanceSubjectKind.MANIFEST,
        implementation_identity=PHEROOS_IMPLEMENTATION_ID,
        artifact_digest=artifact_digest(manifest_path),
    )


def run_source_conformance(core_root: str | Path | None = None) -> ConformanceReport:
    """Prove repository/package source cohesion under an explicit profile.

    The root is never inferred from the current working directory.  When it is
    omitted, it is resolved from the installed ``pheroos.conformance`` package
    location, which is reliable for source/editable installs.  A wheel without
    all required source surfaces fails the ``source_surface`` check instead of
    receiving an empty-scan pass.
    """

    root = (
        Path(core_root).resolve()
        if core_root is not None
        else Path(__file__).resolve().parents[2]
    )
    checks = [
        safe_check("source_surface", source_surface.check, root),
        safe_check(
            "domain_neutrality_public_core", domain_neutrality.check_public_core, root
        ),
        safe_check("package_import_boundary", kernel_import_boundary.check, root),
        safe_check("driver_lifecycle_boundary", driver_lifecycle_boundary.check),
        safe_check("runtime_scope_contract", runtime_scope_contract.check),
        safe_check("authority_ledger_contract", authority_ledger_contract.check),
        safe_check("trace_store_contract", trace_store_contract.check),
        safe_check("public_abi_boundary", public_abi_boundary.check, root),
    ]
    checks.append(profile_contract_check(SOURCE_PROFILE, checks))
    return ConformanceReport(
        target=str(root),
        checks=tuple(checks),
        profile=SOURCE_PROFILE.version,
        subject_kind=ConformanceSubjectKind.SOURCE_ABI,
        implementation_identity=PHEROOS_IMPLEMENTATION_ID,
        artifact_digest=artifact_digest(root, source_surface=True),
    )


def artifact_digest(path: str | Path, *, source_surface: bool = False) -> str:
    """Hash the conformance subject without binding reports to an absolute CWD."""

    target = Path(path).resolve()
    digest = sha256()
    if target.is_file():
        digest.update(target.read_bytes())
        return "sha256:" + digest.hexdigest()
    if not target.is_dir():
        digest.update(b"missing\0")
        digest.update(str(target).encode("utf-8"))
        return "sha256:" + digest.hexdigest()
    if not source_surface:
        manifest = target / "capability.json"
        if manifest.is_file():
            digest.update(manifest.read_bytes())
            return "sha256:" + digest.hexdigest()
    candidates: list[Path] = []
    for relative_root, pattern in (
        ("pheroos", "*.py"),
        ("schemas", "*.json"),
    ):
        base = target / relative_root
        if base.is_dir():
            candidates.extend(base.rglob(pattern))
    if (target / "pyproject.toml").is_file():
        candidates.append(target / "pyproject.toml")
    for item in sorted(
        set(candidates), key=lambda value: value.relative_to(target).as_posix()
    ):
        relative = item.relative_to(target).as_posix().encode("utf-8")
        payload = item.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return "sha256:" + digest.hexdigest()


def safe_check(name: str, check: Callable[..., CheckResult], *args: Any) -> CheckResult:
    try:
        result = check(*args)
    except Exception as exc:
        return exception_result(name, exc)
    if not isinstance(result, CheckResult):
        return CheckResult(
            name, False, f"invalid check result type: {type(result).__name__}"
        )
    if result.name != name:
        return CheckResult(
            name, False, f"check returned mismatched name: {result.name}"
        )
    return result


def exception_result(name: str, exc: Exception) -> CheckResult:
    detail = str(exc).strip()
    suffix = f": {detail}" if detail else ""
    return CheckResult(name, False, f"{type(exc).__name__}{suffix}")


def profile_contract_check(
    profile: ConformanceProfile, checks: list[CheckResult]
) -> CheckResult:
    observed = {check.name: check for check in checks}
    missing = [name for name in profile.required_checks if name not in observed]
    failing = [
        name
        for name in profile.required_checks
        if name in observed and not observed[name].ok
    ]
    detail = ", ".join(
        [f"missing:{name}" for name in missing] + [f"failed:{name}" for name in failing]
    )
    return CheckResult("profile_contract", not missing and not failing, detail)


__all__ = [
    "MANIFEST_CHECKS",
    "artifact_digest",
    "profile_contract_check",
    "run_conformance",
    "run_source_conformance",
    "safe_check",
    "validate_manifest",
]
