"""Experimental finite campaign allotments; Session remains the receipt owner.

An allocation reserves a whole child Session's limits before it is created.
Settled usage and unresolved upper bounds are read only from that child's
terminal ledger. This is a budget allocator, not another model billing ledger.
Model slots are claimed before dispatch through CampaignDriver. Tools retain
their separate child Session call limit. Missing receipts never release tokens.
"""

from contextlib import contextmanager
from hashlib import sha256
import json
from pathlib import Path
import sqlite3

from .session_v1 import Session
from .store import BudgetExceeded, StateError


def _integer(value, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError("exact nonnegative integer required")
    return value


def _wire(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


class CampaignBudget:
    """Trusted single-host allocator shared by finite episode/fork workers."""

    def __init__(self, path):
        self.path = str(Path(path).resolve())

    @contextmanager
    def _transaction(self):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA synchronous=FULL")
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @classmethod
    def create(cls, path, *, token_cap, dispatch_cap, config_digest):
        _integer(token_cap)
        _integer(dispatch_cap, 1)
        if (type(config_digest) is not str or len(config_digest) != 64
                or any(c not in "0123456789abcdef" for c in config_digest)):
            raise ValueError("SHA256 configuration identity required")
        with Path(path).open("xb"):
            pass
        result = cls(path)
        with result._transaction() as db:
            db.execute("CREATE TABLE campaign (token_cap INTEGER, dispatch_cap INTEGER, "
                       "config_digest TEXT, violation TEXT)")
            db.execute("INSERT INTO campaign VALUES (?,?,?,NULL)",
                       (token_cap, dispatch_cap, config_digest))
            db.execute("CREATE TABLE allotments (id TEXT PRIMARY KEY, path TEXT UNIQUE, "
                       "tokens INTEGER, calls INTEGER, model_cap INTEGER, held_tokens INTEGER, held_calls INTEGER, "
                       "state TEXT, snapshot_digest TEXT, known_tokens INTEGER, unknown_tokens INTEGER)")
            db.execute("CREATE TABLE model_slots (allocation_id TEXT, call_id TEXT, "
                       "PRIMARY KEY(allocation_id,call_id))")
        return result

    def allocate(self, allocation_id, session_path, *, token_cap, max_calls, model_dispatches=None):
        _integer(token_cap)
        _integer(max_calls, 1)
        model_dispatches = max_calls if model_dispatches is None else _integer(model_dispatches)
        if model_dispatches > max_calls:
            raise ValueError("model allotment exceeds total child calls")
        if type(allocation_id) is not str or not allocation_id or len(allocation_id) > 128:
            raise ValueError("bounded allocation identity required")
        path = str(Path(session_path).resolve())
        if Path(path).exists():
            raise StateError("allocation must precede child Session creation")
        with self._transaction() as db:
            campaign = db.execute("SELECT * FROM campaign").fetchone()
            used = db.execute("SELECT COALESCE(SUM(held_tokens),0), "
                              "COALESCE(SUM(held_calls),0) FROM allotments").fetchone()
            if campaign["violation"]:
                raise StateError("campaign violation is retained; further allocation stopped")
            if used[0] + token_cap > campaign["token_cap"] or used[1] + model_dispatches > campaign["dispatch_cap"]:
                raise BudgetExceeded("campaign worst-case allotment exceeds remaining budget")
            db.execute("INSERT INTO allotments VALUES (?,?,?,?,?,?,?,'allocated',NULL,NULL,NULL)",
                       (allocation_id, path, token_cap, max_calls, model_dispatches, token_cap, model_dispatches))
        return {"token_cap": token_cap, "max_calls": max_calls}

    def reserve_model_slot(self, allocation_id, session_path, call_id):
        """A unique dispatch intent, claimed before any model execution.

        No retry API exists. The child Session supplies the dispatch/receipt
        history; an intent alone is not a charge or permission to act.
        """
        if type(call_id) is not str or not call_id or len(call_id) > 128:
            raise ValueError("bounded model call identity required")
        with self._transaction() as db:
            row = db.execute("SELECT * FROM allotments WHERE id=?", (allocation_id,)).fetchone()
            if (row is None or row["state"] != "allocated"
                    or row["path"] != str(Path(session_path).resolve())):
                raise StateError("active allocation for this Session required")
            if db.execute("SELECT violation FROM campaign").fetchone()[0]:
                raise StateError("campaign violation stops dispatch")
            if db.execute("SELECT 1 FROM model_slots WHERE allocation_id=? AND call_id=?",
                          (allocation_id, call_id)).fetchone():
                raise StateError("model slot cannot be retried; reconcile original Session call")
            count = db.execute("SELECT COUNT(*) FROM model_slots WHERE allocation_id=?",
                               (allocation_id,)).fetchone()[0]
            if count >= row["model_cap"]:
                raise BudgetExceeded("allocation model-dispatch limit reached")
            db.execute("INSERT INTO model_slots VALUES (?,?)", (allocation_id, call_id))

    def reconcile(self, allocation_id):
        """Refresh a terminal child's usage, including later known settlement.

        A live child cannot release capacity. Missing/corrupt children retain
        their entire allocation. Any cap inconsistency is durably flagged and
        closes admission instead of rewriting the child's observation.
        """
        failure = None
        with self._transaction() as db:
            row = db.execute("SELECT * FROM allotments WHERE id=?", (allocation_id,)).fetchone()
            if row is None:
                raise StateError("unknown allocation")
            if not Path(row["path"]).is_file():
                raise StateError("missing Session retains complete allocation")
            snapshot = Session(row["path"]).snapshot()
            run = snapshot["run"]
            if run["status"] not in {"completed", "cancelled", "revoked"}:
                raise StateError("only terminal Sessions release unused capacity")
            limits = json.loads(run["limits"])
            known, unknown = snapshot["actual_tokens"], snapshot["unknown_tokens"]
            held = known + unknown + snapshot["reserved_tokens"]
            calls = sum(c["action"] == "model.generate" for c in snapshot["calls"])
            slot_ids = {r[0] for r in db.execute("SELECT call_id FROM model_slots WHERE allocation_id=?", (allocation_id,))}
            observed_ids = {c["id"] for c in snapshot["calls"] if c["action"] == "model.generate"}
            if (limits["token_cap"] != row["tokens"] or limits["max_calls"] != row["calls"]
                    or held > row["tokens"] or snapshot["call_count"] > row["calls"]
                    or calls > row["model_cap"] or not observed_ids <= slot_ids):
                failure = "child_limits_or_usage_exceed_allotment"
                db.execute("UPDATE campaign SET violation=?", (failure,))
                # No decrease, even if a forged/superseded child looks cheap.
                held, calls = max(held, row["held_tokens"]), max(calls, row["held_calls"])
            db.execute("UPDATE allotments SET held_tokens=?,held_calls=?,state=?,"
                       "snapshot_digest=?,known_tokens=?,unknown_tokens=? WHERE id=?",
                       (held, calls, "violation" if failure else "terminal",
                        sha256(_wire(snapshot).encode()).hexdigest(), known, unknown, allocation_id))
        if failure:
            raise StateError(failure)
        return self.snapshot()

    def snapshot(self):
        with self._transaction() as db:
            campaign = dict(db.execute("SELECT * FROM campaign").fetchone())
            rows = [dict(r) for r in db.execute("SELECT * FROM allotments ORDER BY rowid")]
        return {"schema": "campaign_allotments_v1", **campaign, "allotments": rows,
                "held_token_upper_bound": sum(r["held_tokens"] for r in rows),
                "held_call_slots": sum(r["held_calls"] for r in rows),
                "known_tokens": sum(r["known_tokens"] or 0 for r in rows),
                "known_tokens_complete": all(r["known_tokens"] is not None for r in rows),
                "dispatch_cap_basis": "unique model dispatch intents, reconciled from terminal Session calls"}


class CampaignDriver:
    """One concrete bounded generation caller; delegate other operations unchanged."""

    def __init__(self, driver, campaign, allocation_id):
        self.driver, self.campaign, self.allocation_id = driver, campaign, allocation_id

    def generate(self, lease, call_id, model_ref, messages, *, max_new_tokens, seed):
        self.campaign.reserve_model_slot(self.allocation_id, self.driver.session.path, call_id)
        return self.driver.generate(lease, call_id, model_ref, messages,
                                    max_new_tokens=max_new_tokens, seed=seed)
