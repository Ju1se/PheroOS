"""Experimental session adapters; execution stays outside ledger transactions.

Model replies are proposals. Only a separately verified tool artifact can be
published. This module imports no model or numerical package by default.
"""

from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path
from time import monotonic_ns
from typing import Protocol

from .authority import authorize, authorize_r3


class ModelAdapter(Protocol):
    identity: dict

    def count_tokens(self, messages: list[dict]) -> int: ...

    def generate(self, messages: list[dict], max_new_tokens: int, seed: int) -> dict: ...


class LocalModelAdapter:
    """Opt-in local CUDA adapter, reusing the frozen model loading contract."""

    def __init__(self, model_path):
        from .r3_local import LocalModel

        root = Path(model_path).resolve()
        manifest = json.loads((root / "manifest.json").read_text())
        hashes = manifest.get("sha256")
        if type(hashes) is not dict or not hashes:
            raise ValueError("model manifest requires file hashes")
        for name, expected in hashes.items():
            path = (root / name).resolve()
            if (not path.is_relative_to(root) or not path.is_file()
                    or sha256(path.read_bytes()).hexdigest() != expected):
                raise ValueError(f"model manifest hash mismatch: {name}")
        self.model = LocalModel(root)
        if self.model.identity["model_manifest"] != manifest:
            raise ValueError("model manifest changed during loading")
        self.identity = self.model.identity

    def count_tokens(self, messages):
        return int(self.model.inputs(messages)["input_ids"].shape[-1])

    def generate(self, messages, max_new_tokens, seed):
        return self.model.generate(messages, max_new_tokens, seed)


def current_authorization(scope, task_id, version, action, payload):
    callback = authorize if action == "tool.evaluate" else authorize_r3
    return callback(scope, task_id, version, action, payload)


def _copy(value):
    return json.loads(json.dumps(value, sort_keys=True, allow_nan=False))


class SessionDriver:
    """Concrete model/tool dispatch for a declared session work item.

    Registry keys identify available adapters, not permissions. Session checks
    the work/lease/action and current authorization again at actual dispatch.
    An exception after dispatch retains the reservation as unknown; this driver
    never retries it. Committed receipt replay is explicit and has no authority.
    """

    def __init__(self, session, *, models=None, tools=None,
                 authorization=current_authorization, context_tokens=2048):
        if type(context_tokens) is not int or context_tokens < 1:
            raise ValueError("positive context bound required")
        self.session = session
        self.models, self.tools = dict(models or {}), dict(tools or {})
        self.authorization, self.context_tokens = authorization, context_tokens

    def generate(self, lease, call_id, model_ref, messages, *, max_new_tokens, seed):
        model = self.models[model_ref]
        messages = _copy(messages)
        prompt_tokens = model.count_tokens(messages)
        if (type(prompt_tokens) is not int or prompt_tokens < 1
                or type(max_new_tokens) is not int or max_new_tokens < 1
                or type(seed) is not int or seed < 0):
            raise ValueError("invalid generation bounds")
        if prompt_tokens + max_new_tokens > self.context_tokens:
            raise ValueError("model context bound exceeded")
        payload = {"task_id": lease.task_id, "version": lease.version,
                   "model_ref": model_ref, "model_identity": _copy(model.identity),
                   "messages": messages, "max_new_tokens": max_new_tokens, "seed": seed}
        self.session.reserve(lease, call_id, "model.generate", payload,
                             prompt_tokens=prompt_tokens, max_new_tokens=max_new_tokens)
        self.session.dispatch(lease, call_id, self.authorization)
        started = monotonic_ns()
        response = _copy(model.generate(messages, max_new_tokens, seed))
        response["model_ref"] = model_ref
        response["adapter_elapsed_ns"] = monotonic_ns() - started
        self.session.receive(call_id, response)
        return response

    def evaluate(self, lease, call_id, tool_ref, arguments):
        tool = self.tools[tool_ref]
        arguments = _copy(arguments)
        payload = {"task_id": lease.task_id, "version": lease.version,
                   "tool_ref": tool_ref, "arguments": arguments}
        self.session.reserve(lease, call_id, "tool.evaluate", payload,
                             prompt_tokens=0, max_new_tokens=0)
        self.session.dispatch(lease, call_id, self.authorization)
        started = monotonic_ns()
        artifact = _copy(tool(arguments))
        response = {"artifact": artifact, "tool_ref": tool_ref,
                    "prompt_tokens": 0, "completion_tokens": 0,
                    "adapter_elapsed_ns": monotonic_ns() - started}
        self.session.receive(call_id, response)
        return response

    def replay(self, call_id):
        """Retrieve a settled receipt without executing, charging, or authorizing."""
        record = self.session.call(call_id)
        if record["state"] != "received":
            raise ValueError("unresolved call cannot be replayed or redispatched")
        return _copy(record["response"])
