"""External G1 prototype. No production or swarm efficacy guarantee."""
