"""Two fixed, pure operations exercised through public Driver v2 envelopes."""

from pheroos.drivers import (
    DriverDescriptor,
    DriverInvocationReceiptV2,
    DriverInvocationReplyV2,
    DriverInvocationRequestV2,
    DriverInvocationResultV2,
    bind,
    expose,
    probe,
    register,
)


def invoke(scope, call_id: str, action: str, payload: dict) -> DriverInvocationReplyV2:
    if action not in ("mock.propose", "tool.evaluate"):
        raise ValueError("only mock proposal and pure integer tool are installed")
    descriptor = DriverDescriptor(
        id=f"driver.{action}",
        kind="tool",
        version="1",
        capabilities=[f"capability:{action}"],
        permissions=["driver:invoke"],
    )
    registration = register(descriptor)
    probe(registration)
    expose(
        bind(
            registration,
            tenant_id=scope.tenant_id,
            run_id=scope.run_id,
            permissions=("driver:invoke",),
        )
    )
    request = DriverInvocationRequestV2(
        scope_ref=scope.scope_ref,
        driver_id=descriptor.id,
        invocation_id=call_id,
        operation="driver:invoke",
        capability=f"capability:{action}",
        idempotency_key=call_id,
        payload=payload,
    )
    inputs = payload["inputs"]
    if not isinstance(inputs, list) or not inputs or any(type(x) is not int for x in inputs):
        raise ValueError("integer inputs required")
    kind = payload["kind"]
    if kind not in ("square", "sum") or (kind == "square" and len(inputs) != 1):
        raise ValueError("undeclared task operation")
    if action == "mock.propose":
        output = {"operation": kind}
    else:
        if payload["operation"] != kind:
            raise ValueError("proposal does not match the declared task")
        output = {"value": inputs[0] ** 2 if kind == "square" else sum(inputs)}
    result = DriverInvocationResultV2(
        scope_ref=request.scope_ref,
        driver_id=request.driver_id,
        invocation_id=call_id,
        operation=request.operation,
        capability=request.capability,
        idempotency_key=call_id,
        request_digest=request.request_digest,
        ok=True,
        payload=output,
        provenance="provider-free:g1-pure-adapter",
    )
    receipt = DriverInvocationReceiptV2(
        scope_ref=request.scope_ref,
        driver_id=request.driver_id,
        invocation_id=call_id,
        operation=request.operation,
        capability=request.capability,
        idempotency_key=call_id,
        provenance=result.provenance,
        request_digest=request.request_digest,
        result_digest=result.result_digest,
    )
    return DriverInvocationReplyV2(request, result, receipt)
