"""Mock-only host adapter for the public Draft Baseline Output v2 contract.

The trusted single-process host supplies declarations; the core checks their
scope, grant, evidence, stop, action and payload bindings in an in-memory Store.
Each invocation builds fresh authority and checks current Store inclusion. The
returned dictionary is audit evidence, never an execution capability. Durable
runtime task versions/cancellation are checked by the caller immediately before
this function. Restart does not deserialize authority or restore revoked grants.

The public conformance reference adapter is a development fixture outside the
121-symbol consumer candidate. This is not an independent authority Store or a
production trust boundary against a malicious host.
"""

from __future__ import annotations

from hashlib import sha256
import json

from pheroos.conformance import ReferenceGovernanceStateStoreConformanceAdapterV2
from pheroos.governance import (
    BaselineOutputActionDispositionV2,
    BaselineOutputDeliveryDispositionV2,
    BaselineOutputRequestV2,
    BaselineOutputResultV2,
    GovernanceCommitDispositionV2,
    GovernanceIssuerGrantV2,
    GovernanceIssuerOperationV2,
    GovernanceVerifiedSignalRequestV2,
    baseline_verified_signal_proposal_root_v2,
    evaluate_and_commit_governed_baseline_output_v2,
    recover_baseline_output_result_v2,
)
from pheroos.kernel import RuntimeScope
from pheroos.protocol import read_capability_manifest, validate_capability_manifest


ACTIONS = frozenset({"mock.propose", "tool.evaluate", "artifact.publish"})
R3_ACTIONS = frozenset({"model.generate", "artifact.publish"})
STORE_CONFORMANCE_VERSION = "pheroos-governance-state-store-conformance-v2"


def _root(value: object) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return "sha256:" + sha256(encoded.encode("utf-8")).hexdigest()


def _json_value(value: object) -> bool:
    # Match the core's portable integer-only canonical payload surface.
    if value is None or type(value) in (str, int, bool):
        return True
    if type(value) is list:
        return all(_json_value(item) for item in value)
    if type(value) is dict:
        return all(type(key) is str and _json_value(item) for key, item in value.items())
    return False


def _manifest(target: str, action: str, *, r3: bool = False):
    authority = {
        "policy_version": "pheroos-scoped-authority-policy-v2",
        "profile": "pheroos-scoped-authority-local-v2",
        "wire_version": "pheroos-authority-wire-v2",
        "canonical_version": "pheroos-authority-canonical-v2",
        "ledger_version": "pheroos-governance-authority-ledger-v2",
        "state_store_version": "pheroos-governance-state-store-v2",
        "trace_batch_version": "pheroos-governance-trace-batch-v2",
        "read_set_version": "pheroos-governance-authority-read-set-v2",
    }
    manifest = read_capability_manifest(
        {
            "id": "r3-local-pilot" if r3 else "g1-local-mock",
            "name": "R3 Local Engineering Pilot" if r3 else "G1 Local Mock",
            "version": "1",
            "permissions": [],
            "required_connections": [],
            "drivers": [],
            "protocol": {
                "protocol_version": "pheroos.protocol.v2",
                "id": "r3.local.pilot.v1" if r3 else "g1.local.mock",
                "targets": [{"id": target}],
                "signals": [],
                "candidates": [
                    {"id": "candidate:accept", "target": target},
                    {"id": "candidate:fallback", "target": target, "safe_fallback": True},
                ],
                "quorum_policy": {
                    "target": target,
                    "fallback_candidate": "candidate:fallback",
                    "commit_threshold": 1,
                },
                "authority_policy": authority,
                "recovery_protocols": [],
                "evidence_policy": {"require_provenance": True, "allow_agent_fact_creation": False},
                "output_policy": {
                    "policy_version": "pheroos-baseline-output-policy-v2",
                    "decision_mode": "quorum",
                    "actions": [
                        {
                            "action_ref": action,
                            "effect": "publish" if action == "artifact.publish" else "execute",
                            "target": target,
                            "allowed_outcomes": ["evidence_commit"],
                        }
                    ],
                },
                "trace_policy": {
                    "required_events": [
                        "baseline_action_permission_issued",
                        "baseline_decision_evaluated",
                        "baseline_evidence_qualified",
                        "baseline_manifest_activated",
                        "baseline_output_committed",
                        "baseline_stop_resolved",
                        "block",
                        "commit",
                        "output",
                        "recovery",
                    ]
                },
            },
        },
        schema_version="pheroos-capability-schema-v3",
    )
    if any(item.level == "error" for item in validate_capability_manifest(manifest)):
        raise PermissionError("host authority manifest failed core validation")
    return manifest.protocol


def authorize(
    scope: RuntimeScope,
    task_id: str,
    version: int,
    action: str,
    payload: dict,
    *,
    adapter=None,
) -> dict:
    """Authorize one immediate mock action and return non-authoritative evidence.

    ``adapter`` is injectable for public Store conformance/failure checks. The
    caller must not queue this returned projection for later execution: call
    authorize again at the actual dispatch/publication boundary after recovery.
    """
    return _authorize(scope, task_id, version, action, payload, adapter=adapter, r3=False)


def authorize_r3(
    scope: RuntimeScope,
    task_id: str,
    version: int,
    action: str,
    payload: dict,
    *,
    adapter=None,
) -> dict:
    """Check fresh public-core gates for one R3 generation/publication boundary.

    This is an explicit trusted-host engineering profile. Its declarations do
    not establish truth of model output or production durability of authority.
    The returned evidence must not be replayed as an execution permission.
    """
    return _authorize(scope, task_id, version, action, payload, adapter=adapter, r3=True)


def _authorize(scope, task_id, version, action, payload, *, adapter, r3):
    if type(scope) is not RuntimeScope:
        raise PermissionError("exact RuntimeScope required")
    scope.to_dict()
    if type(task_id) is not str or not task_id.strip() or type(version) is not int or version < 1:
        raise PermissionError("task identity/version invalid")
    if action not in (R3_ACTIONS if r3 else ACTIONS):
        raise PermissionError("action is not declared for this runtime profile")
    if type(payload) is not dict or not payload or not _json_value(payload):
        raise PermissionError("payload must be a nonempty canonical JSON object")
    if payload.get("task_id") != task_id or payload.get("version") != version:
        raise PermissionError("payload task/version binding mismatch")
    if "scope_ref" in payload and payload["scope_ref"] != scope.scope_ref:
        raise PermissionError("payload scope binding mismatch")
    # Detach caller-owned data before deriving roots or asking the core to commit.
    payload = json.loads(json.dumps(payload, allow_nan=False))
    selected = adapter or ReferenceGovernanceStateStoreConformanceAdapterV2()
    if selected.conformance_version != STORE_CONFORMANCE_VERSION:
        raise PermissionError("unsupported authority Store conformance version")
    domain = selected.create_domain_v2(scope.scope_ref)
    store = selected.create_store_v2((domain,))
    label = _root([scope.to_dict(), task_id, version, action, payload])[7:]
    target = "task:" + _root([task_id, version])[7:]
    manifest = _manifest(target, action, r3=r3)
    grant = GovernanceIssuerGrantV2(
        domain_root=domain.domain_root,
        scope_ref=scope.scope_ref,
        issuer_ref="issuer:r3-trusted-host" if r3 else "issuer:g1-trusted-host",
        grant_ref=f"grant:{label}",
        grant_binding_ref=_root(["host-policy", label]),
        operations=tuple(
            GovernanceIssuerOperationV2(value)
            for value in (
                "verify_signal",
                "evaluate_quorum",
                "qualify_evidence",
                "resolve_stop",
                "issue_action_permission",
                "authorize_output",
            )
        ),
        target_refs=(target,),
        action_refs=(action,),
        issued_epoch=1,
        not_before_epoch=1,
        expires_at_epoch=3,
        revocation_generation=0,
    )
    evidence_root, provenance_ref = _root(["host-validated-input", label]), _root(["host", label])
    signal_ref = f"signal:{label}"
    source_ref = "source:r3-trusted-host" if r3 else "source:g1-trusted-host"
    signal_root = baseline_verified_signal_proposal_root_v2(
        domain_root=domain.domain_root,
        scope_ref=scope.scope_ref,
        run_ref=scope.run_id,
        target_ref=target,
        candidate_ref="candidate:accept",
        signal_ref=signal_ref,
        evidence_root=evidence_root,
        provenance_ref=provenance_ref,
        source_ref=source_ref,
    )
    signal = GovernanceVerifiedSignalRequestV2(
        domain_root=domain.domain_root,
        scope_ref=scope.scope_ref,
        run_ref=scope.run_id,
        request_ref=f"request:signal:{label}",
        transition_id=f"transition:signal:{label}",
        signal_ref=signal_ref,
        target_ref=target,
        signal_root=signal_root,
        evidence_root=evidence_root,
        status="verified",
        observed_epoch=2,
    )
    request = BaselineOutputRequestV2(
        domain_root=domain.domain_root,
        scope_ref=scope.scope_ref,
        run_ref=scope.run_id,
        request_ref=f"request:output:{label}",
        output_transition_id=f"transition:output:{label}",
        manifest=manifest,
        target_ref=target,
        action_ref=action,
        proposed_candidate_ref=None,
        verified_signals=(
            {
                "candidate_ref": "candidate:accept",
                "evidence_root": evidence_root,
                "provenance_ref": provenance_ref,
                "signal_ref": signal_ref,
                "signal_root": signal_root,
                "signal_transition_id": signal.transition_id,
                "source_ref": source_ref,
            },
        ),
        stop_resolutions=(
            {
                "action_ref": action,
                "blocked": False,
                "provenance_ref": _root(["clear", label]),
                "reason_ref": "reason:r3-host-approved" if r3 else "reason:mock-host-approved",
            },
        ),
        output_payload=payload,
        observed_epoch=2,
    )
    result = evaluate_and_commit_governed_baseline_output_v2(
        store,
        domain,
        grant,
        f"transition:activate:{label}",
        1,
        request,
        verified_signal_requests=(signal,),
    )
    _require_authorized(result)
    current = recover_baseline_output_result_v2(request, state_reader=store)
    _require_authorized(current)
    permission = current.authorization
    if (
        permission.target_ref != target
        or permission.action_ref != action
        or permission.scope_ref != scope.scope_ref
        or permission.output_payload_root != request.output_payload_root
    ):
        raise PermissionError("core permission binding mismatch")
    return {
        "authority_contract": "pheroos-baseline-output-result-v2",
        "authority_store": selected.implementation_id,
        "scope_ref": scope.scope_ref,
        "task_id": task_id,
        "version": version,
        "target_ref": target,
        "action": action,
        "result_root": current.result_root,
        "permission_root": current.permission_root,
        "output_payload_root": current.output_payload_root,
        "reusable_authority": False,
    }


def _require_authorized(result: object) -> None:
    if (
        not isinstance(result, BaselineOutputResultV2)
        or result.disposition is not GovernanceCommitDispositionV2.COMMITTED
        or result.delivery_disposition is not BaselineOutputDeliveryDispositionV2.DELIVERABLE
        or result.action_disposition is not BaselineOutputActionDispositionV2.AUTHORIZED
        or result.authorization is None
    ):
        raise PermissionError("core denied current host action authorization")
