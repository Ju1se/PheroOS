import argparse
import json

from .engine import run
from .store import Store


def main() -> int:
    parser = argparse.ArgumentParser(description="PheroOS mock-only G1 runtime")
    parser.add_argument("command", choices=("create", "resume", "status", "cancel"))
    parser.add_argument("database")
    parser.add_argument("--run-id", default="g1-demo")
    parser.add_argument("--workers", type=int, choices=(1, 4, 8), default=1)
    parser.add_argument("--policy", choices=("fifo", "blackboard"), default="fifo")
    parser.add_argument("--budget", type=int, default=26)
    args = parser.parse_args()
    if args.command == "create":
        Store.create(args.database, args.run_id, args.budget)
    store = Store(args.database)
    if args.command == "cancel":
        store.cancel()
    if args.command == "resume":
        store.recover()
        report = run(args.database, workers=args.workers, policy=args.policy)
    else:
        report = store.snapshot()
    summary = {
        k: v for k, v in report.items() if k not in ("tasks", "calls", "events", "artifacts")
    }
    summary["tasks_done"] = sum(t["status"] == "done" for t in report["tasks"])
    summary["final_value"] = next(
        (a["value"] for a in report["artifacts"] if a["task_id"] == "total"), None
    )
    print(json.dumps(summary, indent=2))
    return 0 if args.command != "resume" or report["run"]["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
