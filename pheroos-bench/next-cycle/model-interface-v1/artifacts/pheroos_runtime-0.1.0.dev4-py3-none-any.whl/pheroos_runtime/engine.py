"""Finite multiprocessing executor; policies differ only in ready-task selection."""

import multiprocessing
import time
from uuid import uuid4

from .adapters import invoke
from .authority import authorize
from .store import BudgetExceeded, LeaseLost, Store


def execute(store: Store, lease):
    context = store.context(lease)
    scope = store.scope(lease.task_id)
    outputs = {}
    for action in ("mock.propose", "tool.evaluate"):
        payload = context if action == "mock.propose" else context | outputs["mock.propose"]
        call_id = store.reserve(lease, action, payload)
        call = store.call(call_id)
        if call["state"] == "received":
            output = call["response"]
        else:
            request = store.dispatch(lease, call_id, authorize)
            reply = invoke(scope, call_id, action, request)
            output = dict(reply.result.payload)
            store.receive(
                call_id,
                output,
                driver_receipt={
                    "scope_ref": reply.receipt.scope_ref,
                    "driver_id": reply.receipt.driver_id,
                    "invocation_id": reply.receipt.invocation_id,
                    "request_digest": reply.receipt.request_digest,
                    "result_digest": reply.receipt.result_digest,
                    "provenance": reply.receipt.provenance,
                },
            )
        outputs[action] = output
    store.publish(lease, outputs["tool.evaluate"]["value"], scope.scope_ref, authorize)


def worker(path: str, policy: str):
    store = Store(path)
    owner = uuid4().hex
    while True:
        lease = store.claim(owner, policy=policy)
        if lease is None:
            snap = store.snapshot()
            if snap["run"]["status"] != "running" or not any(
                t["status"] == "leased" for t in snap["tasks"]
            ):
                return
            time.sleep(0.02)
            continue
        try:
            execute(store, lease)
        except BudgetExceeded:
            store.relinquish(lease, "budget_exhausted")
            return
        except LeaseLost:
            # Cancellation or a replacement worker fenced this one out.
            return
        except Exception:
            try:
                store.relinquish(lease, "execution_error")
            except LeaseLost:
                pass
            raise


def run(path: str, *, workers: int = 1, policy: str = "fifo", timeout: float = 120) -> dict:
    if workers not in (1, 4, 8) or policy not in ("fifo", "blackboard"):
        raise ValueError("G1 supports workers=1/4/8 and fifo/blackboard")
    if timeout <= 0:
        raise ValueError("positive timeout required")
    context = multiprocessing.get_context("spawn")
    processes = [context.Process(target=worker, args=(str(path), policy)) for _ in range(workers)]
    started = time.monotonic()
    try:
        for process in processes:
            process.start()
        for process in processes:
            process.join(max(0, timeout - (time.monotonic() - started)))
        if any(p.is_alive() for p in processes):
            raise TimeoutError("worker deadline exceeded; dispatched calls require recovery")
    finally:
        for process in processes:
            if process.is_alive():
                process.kill()
                process.join()
    summary = Store(path).snapshot()
    summary["worker_exitcodes"] = [p.exitcode for p in processes]
    summary["elapsed_seconds"] = time.monotonic() - started
    return summary
