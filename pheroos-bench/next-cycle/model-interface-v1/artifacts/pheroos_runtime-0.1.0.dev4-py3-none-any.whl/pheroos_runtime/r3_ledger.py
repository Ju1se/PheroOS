"""Durable, bounded token accounting for the explicit local R3 pilot."""

import json
import sqlite3
from contextlib import contextmanager


def _integer(value, name):
    if type(value) is not int or value < 0:
        raise ValueError(f"{name} must be an exact nonnegative integer")
    return value


def _json(value):
    if type(value) is not dict:
        raise ValueError("request and response must be dictionaries")
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("request and response must be JSON serializable") from exc


class PilotLedger:
    """Each call has one reservation, at most one dispatch, and one settlement.

    Dispatched calls retain their entire reservation until valid usage arrives.
    No restart, timeout, or malformed response releases an unknown cost.
    """

    def __init__(self, path, token_cap, max_calls):
        self.config = {
            "token_cap": _integer(token_cap, "token_cap"),
            "max_calls": _integer(max_calls, "max_calls"),
        }
        self.db = sqlite3.connect(path, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        try:
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA synchronous=FULL")
            with self._transaction():
                self.db.execute("CREATE TABLE IF NOT EXISTS config (value TEXT NOT NULL)")
                self.db.execute("""CREATE TABLE IF NOT EXISTS calls (
                    id TEXT PRIMARY KEY, state TEXT NOT NULL, request TEXT NOT NULL,
                    response TEXT, prompt_tokens INTEGER NOT NULL,
                    max_new_tokens INTEGER NOT NULL, reserved INTEGER NOT NULL,
                    actual INTEGER)""")
                rows = self.db.execute("SELECT value FROM config").fetchall()
                if not rows:
                    self.db.execute("INSERT INTO config VALUES (?)", (_json(self.config),))
                elif len(rows) != 1 or json.loads(rows[0][0]) != self.config:
                    raise ValueError("ledger configuration does not match")
        except BaseException:
            self.db.close()
            raise

    @contextmanager
    def _transaction(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.commit()
        except BaseException:
            self.db.rollback()
            raise

    def _call(self, call_id):
        row = self.db.execute("SELECT * FROM calls WHERE id = ?", (call_id,)).fetchone()
        if row is None:
            raise ValueError("unknown call id")
        return row

    def reserve(self, call_id, request: dict, prompt_tokens: int, max_new_tokens: int):
        if type(call_id) is not str or not call_id:
            raise ValueError("call id must be a nonempty string")
        encoded = _json(request)
        reserved = (_integer(prompt_tokens, "prompt_tokens")
                    + _integer(max_new_tokens, "max_new_tokens"))
        with self._transaction():
            rows = self.db.execute("SELECT id, state, reserved, actual FROM calls").fetchall()
            if any(row["id"] == call_id for row in rows):
                raise ValueError("call id already reserved")
            used = sum(row["reserved"] if row["state"] in ("reserved", "dispatched")
                       else row["actual"] for row in rows)
            if len(rows) >= self.config["max_calls"] or used + reserved > self.config["token_cap"]:
                raise ValueError("pilot call or token cap exceeded")
            self.db.execute("INSERT INTO calls VALUES (?, 'reserved', ?, NULL, ?, ?, ?, NULL)",
                            (call_id, encoded, prompt_tokens, max_new_tokens, reserved))

    def dispatched(self, call_id):
        with self._transaction():
            if self._call(call_id)["state"] != "reserved":
                raise ValueError("only reserved calls may be dispatched")
            self.db.execute("UPDATE calls SET state = 'dispatched' WHERE id = ?", (call_id,))

    def received(self, call_id, response: dict):
        encoded = _json(response)
        prompt = _integer(response.get("prompt_tokens"), "prompt_tokens")
        completion = _integer(response.get("completion_tokens"), "completion_tokens")
        with self._transaction():
            row = self._call(call_id)
            if row["state"] == "received" and row["response"] == encoded:
                return
            if row["state"] != "dispatched":
                raise ValueError("only dispatched calls may receive usage")
            if prompt != row["prompt_tokens"] or completion > row["max_new_tokens"]:
                raise ValueError("response usage violates reservation")
            self.db.execute("UPDATE calls SET state = 'received', response = ?, actual = ? "
                            "WHERE id = ?", (encoded, prompt + completion, call_id))

    def denied(self, call_id):
        with self._transaction():
            if self._call(call_id)["state"] != "reserved":
                raise ValueError("only undispatched reservations may be denied")
            self.db.execute("UPDATE calls SET state = 'denied', actual = 0 WHERE id = ?",
                            (call_id,))

    def snapshot(self):
        rows = self.db.execute("SELECT * FROM calls ORDER BY rowid").fetchall()
        return {
            "config": dict(self.config),
            "calls": [{"id": row["id"], "state": row["state"],
                       "request": json.loads(row["request"]),
                       "response": json.loads(row["response"]) if row["response"] else None,
                       "reserved": row["reserved"], "actual": row["actual"]} for row in rows],
            "actual_tokens": sum(row["actual"] or 0 for row in rows),
            "reserved_tokens": sum(row["reserved"] for row in rows if row["state"] == "reserved"),
            "unknown_tokens": sum(row["reserved"] for row in rows if row["state"] == "dispatched"),
            "call_count": len(rows),
        }

    def close(self):
        self.db.close()
