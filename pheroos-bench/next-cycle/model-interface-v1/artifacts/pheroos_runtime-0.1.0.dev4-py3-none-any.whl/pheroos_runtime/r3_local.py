"""Finite local R3 JSONL adapter. No network, daemon, or imported model in G1."""

import argparse
from hashlib import sha256
import importlib.metadata
import json
from pathlib import Path
import sys
import time

from pheroos.kernel import RuntimeScope
from .authority import authorize_r3
from .r3_ledger import PilotLedger


def emit(value):
    print(json.dumps(value, allow_nan=False), flush=True)


class LocalModel:
    def __init__(self, model_path):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        if not torch.cuda.is_available():
            raise RuntimeError('R3 requires CUDA; CPU fallback is not a GPU result')
        self.torch = torch
        torch.set_num_threads(4)
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_path, local_files_only=True, trust_remote_code=False)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_path, local_files_only=True, trust_remote_code=False,
            torch_dtype=torch.float16, attn_implementation='sdpa').to('cuda').eval()
        self.identity = {
            'torch': torch.__version__, 'transformers': importlib.metadata.version('transformers'),
            'python': sys.version, 'cuda': torch.version.cuda,
            'gpu': torch.cuda.get_device_name(0), 'dtype': 'float16',
            'model_manifest': json.loads((Path(model_path) / 'manifest.json').read_text()),
        }

    def inputs(self, messages):
        if not isinstance(messages, list) or not messages:
            raise ValueError('nonempty messages required')
        return self.tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=True,
            return_dict=True, return_tensors='pt')

    def generate(self, messages, max_new_tokens, seed):
        torch = self.torch
        inputs = self.inputs(messages).to('cuda')
        count = inputs['input_ids'].shape[-1]
        if count + max_new_tokens > 2048:
            raise ValueError('context exceeds frozen 2048-token bound')
        torch.manual_seed(seed)
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        tick = time.monotonic_ns()
        with torch.inference_mode():
            output = self.model.generate(
                **inputs, max_new_tokens=max_new_tokens, do_sample=True,
                temperature=0.7, top_p=0.9, top_k=50,
                pad_token_id=self.tokenizer.eos_token_id)
        torch.cuda.synchronize()
        generated = output[0, count:]
        return {
            'text': self.tokenizer.decode(generated, skip_special_tokens=True),
            'prompt_tokens': int(count), 'completion_tokens': int(generated.numel()),
            'elapsed_ns': time.monotonic_ns() - tick,
            'peak_cuda_bytes': torch.cuda.max_memory_allocated(),
        }


def handle(model, request):
    operation = request['op']
    if operation == 'tokenize':
        return {'prompt_tokens': int(model.inputs(request['messages'])['input_ids'].shape[-1])}
    if operation == 'ledger':
        ledger = PilotLedger(request['ledger_path'], request['token_cap'], request['max_calls'])
        try:
            return ledger.snapshot()
        finally:
            ledger.close()
    scope = RuntimeScope.from_dict(request['scope'])
    task, version = request['task_id'], request['version']
    if operation == 'publish':
        payload = {'task_id': task, 'version': version,
                   'artifact': request['artifact'], 'verification': request['verification']}
        if request['verification'].get('valid') is not True:
            raise PermissionError('trusted task verifier did not accept the artifact')
        return {'authority': authorize_r3(scope, task, version, 'artifact.publish', payload)}
    if operation != 'generate':
        raise ValueError('unknown R3 operation')
    count = int(model.inputs(request['messages'])['input_ids'].shape[-1])
    maximum = request['max_new_tokens']
    if type(maximum) is not int or not 1 <= maximum <= 256 or count + maximum > 2048:
        raise ValueError('invalid frozen context/output bound')
    ledger = PilotLedger(request['ledger_path'], request['token_cap'], request['max_calls'])
    call_id = request['call_id']
    payload = {'task_id': task, 'version': version, 'call_id': call_id,
               'messages': request['messages'], 'max_new_tokens': maximum,
               'seed': request['seed']}
    try:
        ledger.reserve(call_id, payload, count, maximum)
        try:
            authority = authorize_r3(scope, task, version, 'model.generate', payload)
        except Exception:
            ledger.denied(call_id)
            raise
        ledger.dispatched(call_id)
        # Any exception after dispatch leaves the durable reservation unresolved.
        response = model.generate(request['messages'], maximum, request['seed'])
        ledger.received(call_id, response)
        return response | {'authority': authority, 'ledger': ledger.snapshot()}
    finally:
        ledger.close()



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-path', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((args.model_path / 'manifest.json').read_text())
    for name, digest in manifest['sha256'].items():
        if sha256((args.model_path / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f'model digest mismatch: {name}')
    model = LocalModel(args.model_path)
    emit({'status': 'ready', 'identity': model.identity})
    for line in sys.stdin:
        try:
            reply = handle(model, json.loads(line))
            emit({'ok': True, 'result': reply})
        except Exception as error:
            emit({'ok': False, 'error': f'{type(error).__name__}: {error}'})


if __name__ == '__main__':
    main()
