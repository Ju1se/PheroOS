"""Recorded local adapter with portable metadata for existing authority gates.

Only identity representation changes from recorded_local_v1. The inherited
implementation still generates with temperature=0.7 and top_p=0.9. Strings are
explicit decimal metadata, never replacements for actual generation settings.
"""

from .recorded_local_v1 import RecordedLocalModelAdapter as RecordedLocalModelAdapterV1


class RecordedLocalModelAdapter(RecordedLocalModelAdapterV1):
    def __init__(self, model_path):
        super().__init__(model_path)
        self.identity = self.identity | {
            "adapter": "recorded_local_v2",
            "generation_numeric_encoding": "decimal_strings_v1",
            "generation": self.identity["generation"]
            | {
                "temperature": "0.7",
                "top_p": "0.9",
            },
        }
