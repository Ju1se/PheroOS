"""Experimental recorded generation with a 1,024-token output allowance.

The model-interface diagnostic uses this adapter for both output budgets.
Loading, input tokenization, sampling and receipt fields preserve v2 behavior;
only the declared output ceiling changes. Historical adapters remain frozen.
"""

from hashlib import sha256
import json
import time

from .recorded_local_v2 import RecordedLocalModelAdapter as RecordedLocalModelAdapterV2


class RecordedLocalModelAdapter(RecordedLocalModelAdapterV2):
    def __init__(self, model_path):
        super().__init__(model_path)
        self.identity = self.identity | {
            "adapter": "recorded_local_v3",
            "generation": self.identity["generation"] | {"max_output_tokens": 1024},
        }

    def generate(self, messages, max_new_tokens, seed):
        model, torch = self.model, self.model.torch
        inputs = model.inputs(messages).to("cuda")
        prompt_ids = inputs["input_ids"][0].tolist()
        count = len(prompt_ids)
        if (
            type(max_new_tokens) is not int
            or not 1 <= max_new_tokens <= 1024
            or count + max_new_tokens > 2048
            or type(seed) is not int
            or seed < 0
        ):
            raise ValueError("recorded local v3 generation exceeds declared bounds")
        torch.manual_seed(seed)
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        started = time.monotonic_ns()
        with torch.inference_mode():
            output = model.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
                top_k=50,
                pad_token_id=model.tokenizer.eos_token_id,
            )
        torch.cuda.synchronize()
        generated = output[0, count:]
        token_ids = generated.tolist()
        return {
            "text": model.tokenizer.decode(generated, skip_special_tokens=True),
            "prompt_tokens": count,
            "completion_tokens": len(token_ids),
            "generated_token_ids": token_ids,
            "prompt_token_ids_sha256": sha256(
                json.dumps(prompt_ids, separators=(",", ":")).encode()
            ).hexdigest(),
            "token_counting_basis": "actual_input_and_generated_tensor_ids",
            "elapsed_ns": time.monotonic_ns() - started,
            "peak_cuda_bytes": torch.cuda.max_memory_allocated(),
        }
