"""Single-run SQLite execution state; this is NOT a GovernanceStateStoreV2.

Each dispatch has a durable reservation. Unknown dispatches keep their units.
All task effects are pure until the fenced artifact transaction commits.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import sqlite3
import time
from typing import Callable
from uuid import uuid4

from pheroos.kernel import RuntimeScope
from pheroos.trace import TraceEvent


class StateError(RuntimeError):
    pass


class BudgetExceeded(StateError):
    pass


class LeaseLost(StateError):
    pass


def encode(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass(frozen=True)
class Lease:
    task_id: str
    version: int
    owner: str
    epoch: int


class Store:
    def __init__(self, path: str | Path):
        self.path = str(path)

    @contextmanager
    def transaction(self):
        db = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA synchronous=FULL")
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @classmethod
    def create(cls, path: str | Path, run_id: str, budget: int = 26):
        if type(budget) is not int or budget < 0:
            raise ValueError("budget must be a nonnegative integer")
        scope = RuntimeScope(tenant_id="g1-local", run_id=run_id, request_id="create")
        # O_EXCL protects existing runs, including zero-byte or corrupt stores.
        with Path(path).open("xb"):
            pass
        store = cls(path)
        with store.transaction() as db:
            for statement in (
                "CREATE TABLE run (id INTEGER PRIMARY KEY CHECK(id=1), run_id TEXT, scope_ref TEXT, status TEXT, budget INTEGER)",
                "CREATE TABLE tasks (id TEXT PRIMARY KEY, ordinal INTEGER, kind TEXT, seed INTEGER, deps TEXT, version INTEGER, status TEXT, owner TEXT, epoch INTEGER DEFAULT 0, expires REAL)",
                "CREATE TABLE calls (id TEXT PRIMARY KEY, task_id TEXT REFERENCES tasks(id), version INTEGER, epoch INTEGER, action TEXT, state TEXT, reserved INTEGER, actual INTEGER, request TEXT, response TEXT)",
                "CREATE TABLE artifacts (task_id TEXT PRIMARY KEY REFERENCES tasks(id), version INTEGER, scope_ref TEXT, value INTEGER, parents TEXT, authority TEXT)",
                "CREATE TABLE events (seq INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT, task_id TEXT, payload TEXT)",
            ):
                db.execute(statement)
            db.execute(
                "INSERT INTO run VALUES (1,?,?, 'running',?)", (run_id, scope.scope_ref, budget)
            )
            tasks = [(f"square-{i}", "square", i, []) for i in range(1, 9)]
            tasks += [
                (f"pair-{i}", "sum", None, [f"square-{2 * i - 1}", f"square-{2 * i}"])
                for i in range(1, 5)
            ]
            tasks += [("total", "sum", None, [f"pair-{i}" for i in range(1, 5)])]
            for ordinal, (task_id, kind, seed, deps) in enumerate(tasks):
                db.execute(
                    "INSERT INTO tasks VALUES (?,?,?,?,?,1,'ready',NULL,0,NULL)",
                    (task_id, ordinal, kind, seed, encode(deps)),
                )
            store._event(db, "created", "", {"scope_ref": scope.scope_ref, "budget": budget})
        return store

    def _event(self, db, kind: str, task_id: str, payload: dict):
        event = TraceEvent(
            event_type=f"ext.runtime.{kind}",
            protocol_id="g1.local.mock",
            target=task_id or "run",
            reason=kind,
            lineage=payload,
        )
        event.validate()
        db.execute(
            "INSERT INTO events(event_type,task_id,payload) VALUES (?,?,?)",
            (event.event_type, task_id, encode(asdict(event))),
        )

    def scope(self, task_id: str = "status") -> RuntimeScope:
        with self.transaction() as db:
            row = db.execute("SELECT * FROM run").fetchone()
            return RuntimeScope(tenant_id="g1-local", run_id=row["run_id"], request_id=task_id)

    def _lease(self, db, lease: Lease):
        task = db.execute("SELECT * FROM tasks WHERE id=?", (lease.task_id,)).fetchone()
        run = db.execute("SELECT * FROM run").fetchone()
        if run["status"] != "running":
            raise LeaseLost(f"run is {run['status']}")
        if (
            task is None
            or (task["version"], task["owner"], task["epoch"], task["status"])
            != (lease.version, lease.owner, lease.epoch, "leased")
            or task["expires"] <= time.time()
        ):
            raise LeaseLost("expired, superseded or foreign lease")
        return task

    def _recover(self, db):
        expired = db.execute(
            "SELECT * FROM tasks WHERE status='leased' AND expires<=?", (time.time(),)
        ).fetchall()
        for task in expired:
            for call in db.execute(
                "SELECT * FROM calls WHERE task_id=? AND state IN ('reserved','dispatched')",
                (task["id"],),
            ).fetchall():
                state = "abandoned" if call["state"] == "reserved" else "unknown"
                db.execute("UPDATE calls SET state=? WHERE id=?", (state, call["id"]))
                self._event(
                    db, "recovered_call", task["id"], {"call_id": call["id"], "state": state}
                )
            unknown = db.execute(
                "SELECT 1 FROM calls WHERE task_id=? AND state='unknown'", (task["id"],)
            ).fetchone()
            db.execute(
                "UPDATE tasks SET status=?,owner=NULL,expires=NULL WHERE id=?",
                ("uncertain" if unknown else "ready", task["id"]),
            )
            self._event(
                db, "lease_expired", task["id"], {"epoch": task["epoch"], "unknown": bool(unknown)}
            )

    def recover(self):
        with self.transaction() as db:
            if db.execute("SELECT status FROM run").fetchone()[0] == "running":
                self._recover(db)

    def claim(self, owner: str, *, policy: str = "fifo", lease_seconds: float = 60) -> Lease | None:
        if policy not in ("fifo", "blackboard"):
            raise ValueError("unknown policy")
        if not owner or not 0 < lease_seconds <= 3600:
            raise ValueError("owner and bounded positive lease required")
        with self.transaction() as db:
            if db.execute("SELECT status FROM run").fetchone()[0] != "running":
                return None
            self._recover(db)
            artifacts = {r["task_id"] for r in db.execute("SELECT task_id FROM artifacts")}
            ready = [
                r
                for r in db.execute("SELECT * FROM tasks WHERE status='ready' ORDER BY ordinal")
                if set(json.loads(r["deps"])) <= artifacts
            ]
            if not ready:
                return None
            # Blackboard favors ready consumers of shared results. Both policies
            # use exactly the same observations, tools, verifier and budget.
            if policy == "blackboard":
                ready.sort(key=lambda r: (-len(json.loads(r["deps"])), r["ordinal"]))
            task = ready[0]
            epoch = task["epoch"] + 1
            db.execute(
                "UPDATE tasks SET status='leased',owner=?,epoch=?,expires=? WHERE id=?",
                (owner, epoch, time.time() + lease_seconds, task["id"]),
            )
            self._event(
                db, "claimed", task["id"], {"owner": owner, "epoch": epoch, "policy": policy}
            )
            return Lease(task["id"], task["version"], owner, epoch)

    def context(self, lease: Lease) -> dict:
        with self.transaction() as db:
            task = self._lease(db, lease)
            scope_ref = db.execute("SELECT scope_ref FROM run").fetchone()[0]
            parents = []
            for parent in json.loads(task["deps"]):
                row = db.execute("SELECT * FROM artifacts WHERE task_id=?", (parent,)).fetchone()
                if row is None or row["scope_ref"] != scope_ref or row["version"] != 1:
                    raise StateError("missing or incompatible parent artifact")
                parents.append({k: row[k] for k in ("task_id", "version", "value", "scope_ref")})
            return {
                "task_id": lease.task_id,
                "version": lease.version,
                "kind": task["kind"],
                "inputs": [task["seed"]]
                if task["kind"] == "square"
                else [p["value"] for p in parents],
                "parents": parents,
            }

    def reserve(self, lease: Lease, action: str, request: dict) -> str:
        if action not in ("mock.propose", "tool.evaluate"):
            raise ValueError("undeclared call action")
        wire = encode(request)
        with self.transaction() as db:
            self._lease(db, lease)
            # A recovered known receipt is reused, never recharged or dispatched.
            prior = db.execute(
                "SELECT * FROM calls WHERE task_id=? AND version=? AND action=? AND state IN ('reserved','dispatched','unknown','received') ORDER BY rowid DESC LIMIT 1",
                (lease.task_id, lease.version, action),
            ).fetchone()
            if prior:
                if prior["request"] != wire:
                    raise StateError("same action has different request")
                if prior["state"] != "received":
                    raise StateError("action already reserved, dispatched or unresolved")
                return prior["id"]
            spent = db.execute(
                "SELECT COALESCE(SUM(CASE WHEN state='received' THEN actual WHEN state IN ('reserved','dispatched','unknown') THEN reserved ELSE 0 END),0) FROM calls"
            ).fetchone()[0]
            budget = db.execute("SELECT budget FROM run").fetchone()[0]
            if spent + 1 > budget:
                raise BudgetExceeded("no unreserved call unit remains")
            call_id = uuid4().hex
            db.execute(
                "INSERT INTO calls VALUES (?,?,?,?,?,'reserved',1,NULL,?,NULL)",
                (call_id, lease.task_id, lease.version, lease.epoch, action, wire),
            )
            self._event(
                db,
                "reserved",
                lease.task_id,
                {"call_id": call_id, "action": action, "units": 1, "epoch": lease.epoch},
            )
            return call_id

    def dispatch(self, lease: Lease, call_id: str, authorize: Callable) -> dict:
        with self.transaction() as db:
            self._lease(db, lease)
            call = db.execute("SELECT * FROM calls WHERE id=?", (call_id,)).fetchone()
            if call is None or (call["task_id"], call["version"], call["epoch"], call["state"]) != (
                lease.task_id,
                lease.version,
                lease.epoch,
                "reserved",
            ):
                raise StateError("dispatch requires this lease's reservation")
            scope = RuntimeScope(
                tenant_id="g1-local",
                run_id=db.execute("SELECT run_id FROM run").fetchone()[0],
                request_id=lease.task_id,
            )
            authority = authorize(
                scope, lease.task_id, lease.version, call["action"], json.loads(call["request"])
            )
            self._lease(db, lease)
            db.execute("UPDATE calls SET state='dispatched' WHERE id=?", (call_id,))
            self._event(
                db, "dispatched", lease.task_id, {"call_id": call_id, "authority": authority}
            )
            return json.loads(call["request"])

    def receive(
        self, call_id: str, response: dict, *, actual: int = 1, driver_receipt: dict | None = None
    ):
        if type(actual) is not int or actual != 1:
            raise ValueError("G1 adapter charges exactly one unit per dispatched call")
        wire = encode(response)
        with self.transaction() as db:
            call = db.execute("SELECT * FROM calls WHERE id=?", (call_id,)).fetchone()
            if call is None:
                raise StateError("unknown call")
            if call["state"] == "received":
                if call["response"] != wire or call["actual"] != actual:
                    raise StateError("conflicting duplicate receipt")
                return
            if call["state"] not in ("dispatched", "unknown"):
                raise StateError("receipt without a dispatch")
            # Usage survives cancellation or expiry. This does not authorize an artifact.
            db.execute(
                "UPDATE calls SET state='received',actual=?,response=? WHERE id=?",
                (actual, wire, call_id),
            )
            self._event(
                db,
                "received",
                call["task_id"],
                {"call_id": call_id, "actual": actual, "driver_receipt": driver_receipt},
            )
            unresolved = db.execute(
                "SELECT 1 FROM calls WHERE task_id=? AND state IN ('unknown','dispatched')",
                (call["task_id"],),
            ).fetchone()
            if not unresolved and db.execute("SELECT status FROM run").fetchone()[0] == "running":
                changed = db.execute(
                    "UPDATE tasks SET status='ready' WHERE id=? AND status='uncertain'",
                    (call["task_id"],),
                ).rowcount
                if changed:
                    self._event(db, "reconciled", call["task_id"], {"call_id": call_id})

    def call(self, call_id: str) -> dict:
        with self.transaction() as db:
            row = db.execute("SELECT * FROM calls WHERE id=?", (call_id,)).fetchone()
            if row is None:
                raise StateError("unknown call")
            result = dict(row)
            result["response"] = json.loads(row["response"]) if row["response"] else None
            return result

    def publish(self, lease: Lease, value: int, scope_ref: str, authorize: Callable):
        if type(value) is not int:
            raise ValueError("artifact must be an integer")
        with self.transaction() as db:
            task = self._lease(db, lease)
            run = db.execute("SELECT * FROM run").fetchone()
            if scope_ref != run["scope_ref"]:
                raise StateError("foreign artifact scope")
            deps = json.loads(task["deps"])
            # Independent verifier: multiplication vs model/tool exponentiation.
            expected = (
                task["seed"] * task["seed"]
                if task["kind"] == "square"
                else sum(
                    db.execute("SELECT value FROM artifacts WHERE task_id=?", (p,)).fetchone()[0]
                    for p in deps
                )
            )
            tool = db.execute(
                "SELECT response FROM calls WHERE task_id=? AND version=? AND action='tool.evaluate' AND state='received'",
                (lease.task_id, lease.version),
            ).fetchone()
            if value != expected or tool is None or json.loads(tool[0]) != {"value": value}:
                raise StateError("artifact failed independent verification or lacks tool receipt")
            scope = RuntimeScope(
                tenant_id="g1-local", run_id=run["run_id"], request_id=lease.task_id
            )
            payload = {
                "task_id": lease.task_id,
                "version": lease.version,
                "value": value,
                "parents": deps,
                "scope_ref": scope_ref,
            }
            authority = authorize(scope, lease.task_id, lease.version, "artifact.publish", payload)
            self._lease(db, lease)
            db.execute(
                "INSERT INTO artifacts VALUES (?,?,?,?,?,?)",
                (lease.task_id, lease.version, scope_ref, value, encode(deps), encode(authority)),
            )
            db.execute(
                "UPDATE tasks SET status='done',owner=NULL,expires=NULL WHERE id=?",
                (lease.task_id,),
            )
            self._event(
                db,
                "published",
                lease.task_id,
                payload | {"epoch": lease.epoch, "authority": authority},
            )
            if db.execute("SELECT COUNT(*) FROM tasks WHERE status!='done'").fetchone()[0] == 0:
                db.execute("UPDATE run SET status='completed'")

    def cancel(self):
        with self.transaction() as db:
            if db.execute("SELECT status FROM run").fetchone()[0] != "running":
                return
            db.execute("UPDATE run SET status='cancelled'")
            db.execute(
                "UPDATE tasks SET status='cancelled',owner=NULL,expires=NULL WHERE status!='done'"
            )
            db.execute("UPDATE calls SET state='abandoned' WHERE state='reserved'")
            db.execute("UPDATE calls SET state='unknown' WHERE state='dispatched'")
            self._event(db, "cancelled", "", {})

    def relinquish(self, lease: Lease, reason: str):
        """Graceful worker exit; unresolved dispatches retain their reservation."""
        with self.transaction() as db:
            self._lease(db, lease)
            db.execute(
                "UPDATE calls SET state='abandoned' WHERE task_id=? AND state='reserved'",
                (lease.task_id,),
            )
            db.execute(
                "UPDATE calls SET state='unknown' WHERE task_id=? AND state='dispatched'",
                (lease.task_id,),
            )
            unknown = db.execute(
                "SELECT 1 FROM calls WHERE task_id=? AND state='unknown'", (lease.task_id,)
            ).fetchone()
            db.execute(
                "UPDATE tasks SET status=?,owner=NULL,expires=NULL WHERE id=?",
                ("uncertain" if unknown else "ready", lease.task_id),
            )
            self._event(db, "relinquished", lease.task_id, {"epoch": lease.epoch, "reason": reason})

    def snapshot(self) -> dict:
        with self.transaction() as db:
            run = dict(db.execute("SELECT * FROM run").fetchone())
            calls = [dict(r) for r in db.execute("SELECT * FROM calls ORDER BY rowid")]
            tasks = [dict(r) for r in db.execute("SELECT * FROM tasks ORDER BY ordinal")]
            artifacts = [dict(r) for r in db.execute("SELECT * FROM artifacts ORDER BY task_id")]
            events = [dict(r) for r in db.execute("SELECT * FROM events ORDER BY seq")]
            actual = sum(c["actual"] or 0 for c in calls)
            reserved = sum(
                c["reserved"] for c in calls if c["state"] in ("reserved", "dispatched", "unknown")
            )
            unknown = sum(c["reserved"] for c in calls if c["state"] == "unknown")
            return {
                "run": run,
                "tasks": tasks,
                "calls": calls,
                "artifacts": artifacts,
                "events": events,
                "actual_units": actual,
                "reserved_units": reserved,
                "unknown_units": unknown,
                "remaining_units": run["budget"] - actual - reserved,
                "payload_bytes": sum(
                    len(c["request"].encode()) + len((c["response"] or "").encode()) for c in calls
                ),
                "event_bytes": sum(len(e["payload"].encode()) for e in events),
            }
